<template>
  <div class="home-view">
    <div>
      <h1>Google Books API</h1>
      <a href="books">Go to list book &#8594;</a>
    </div>
  </div>
</template>

<script>

export default {
  name: 'HomeView',

}
</script>
<style lang="scss">
  .home-view{    
    text-align: center;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    h1{
      margin: 0;
      padding: 0;
      font-size: 4rem;
      color: #fff;
    }
    a{
      color: #fff;
      text-decoration: underline;
      font-size: 1.5rem;
      margin: 30px 0 0;
      transition: 0.3s;
      display: inline-block;
      &:hover{
        letter-spacing: 0.2rem;
        color: #000;
        text-decoration: none;
      }
    }
  }
</style>
