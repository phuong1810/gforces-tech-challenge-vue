<template>
  <div class="container">
    <div class="wrap-search">
      <b-form inline class="wrap-search__input" @submit.prevent="searchBooks">
        <b-form-input class="col-12 col-sm-6 mr-sm-2" v-model="keyword" autocomplete="off" type="text" placeholder="Type the keyword here..."></b-form-input>
        <b-form-select class="col-12 col-sm-4 mr-sm-2"v-model="selected" :options="options"></b-form-select>
        <b-button class="col-12 col-sm-2 mb-2 mr-sm-2" type="submit">Search</b-button>
        <!-- <button type="submit" :click="searchBooks()">Search</button> -->
      </b-form>
    </div>
    <div class="list-book row" v-if="posts && posts.length">
      <BookItem v-for="post in posts" :key="post.id" :post="post"/>
      <!-- <div v-for="post in posts" :key="post.id">
       <img  :src="post && post.volumeInfo && post.volumeInfo.imageLinks ? post.volumeInfo.imageLinks.thumbnail : ''" :alt="post.volumeInfo.title"/>
       </div> -->
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import BookItem from './BookItem'

export default {
  name: 'BookView',
  data() {
    return {
       posts: {
        type: Object,
        required: true
      },
      keyword: '',
      errors: [],
      selected: null,
      options: [
        { value: null, text: 'Please select an option' },
        { value: 'newest', text: 'Newest' },
        { value: 'relevance', text: 'Relevance' }
      ]
    }
  },
  components: {
    BookItem
  },
  created() {
    axios.get(`https://www.googleapis.com/books/v1/volumes?q=intitle:Stephen%20King&maxResults=40`)
    .then(response => {
      // console.log(response)
      this.posts = response.data.items
    })
    .catch(e => {
      this.errors.push(e)
    })
  },
  methods:{
    searchBooks(){
      axios.get(`https://www.googleapis.com/books/v1/volumes?q=intitle:${this.keyword}&orderBy=${this.selected}`)
      .then(response => {
        this.posts = response.data.items
      })
      .catch(e => {
        this.errors.push(e)
      })
    }
  }
}
</script>
<style lang="scss">
  .wrap-search{
    position: relative;
    &__input{
      display: flex;
      width: 100%;
      max-width: 700px;
      margin: 30px 0;
      input{
        width: 100%;
        height: 45px;
        padding: 0 20px;
        border-radius: 30px;
        border: 3px solid #ddd;
        outline: none;
        font-size: 1.4rem;
        margin-bottom: 15px;
      }
      select{
        width: 100%;
        height: 45px;
        padding: 0 20px;
        border-radius: 30px;
        border: 3px solid #ddd;
        outline: none;
        font-size: 1.4rem;
        margin-bottom: 15px;
      }
      button{
        background-color: transparent;
        border: 3px solid #fff;
        color: #fff;
        font-size: 1.4rem;
        cursor: pointer;
        padding: 0 2rem;
        border-radius: 30px;
        height: 45px;
        margin-bottom: 15px;
      }
    }
  }
  
 
</style>
