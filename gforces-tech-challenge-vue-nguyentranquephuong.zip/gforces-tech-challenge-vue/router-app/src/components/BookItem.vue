<template>
  <div class="col-12 col-sm-6 col-md-3">
    <div class="book-item">
      <a href="post.volumeInfo.previewLink" title="post.volumeInfo.title">
        <div class="book-item__img">
          <img :src="post && post.volumeInfo && post.volumeInfo.imageLinks ? post.volumeInfo.imageLinks.thumbnail : 'https://via.placeholder.com/150/?text=QuePhuong'" :alt="post.volumeInfo.title"/>
        </div>
        <h3>{{post.volumeInfo.title}}</h3>
        <p>{{post.volumeInfo.description}}</p>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BookItem',
  props: {
    post: {
      type: Object,
      required: true
    }
  }
}
</script>
<style lang="scss">
  .book-item{
    margin-bottom: 30px;
    &__img{
      position: relative;
      padding-bottom: 150%;
      img{
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        object-fit: cover;
      }
    }
    
    a{
      color: #212121;
      &:hover{
        text-decoration: none;
      }
    }
    h3{
      font-size: 1.5rem;
      text-transform: uppercase;
      text-align: center;
      margin: 20px 0;
    }
    p{
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      position: relative;
      z-index: 1;
      text-align: center;
      font-size: 1.4rem;
    }
  }
</style>