<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat&display=swap');
body{
  margin: 0;
}
html{
  font-size: 10px;
}
body{
  font-family: 'Montserrat', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  background-attachment: fixed;
  background-image: linear-gradient(120deg, #caca2b 0%, #8ec5fc 100%);
  overflow-x: hidden;
}
</style>
